package project.system.common.constant;

/*
@author zws
@CreateDate 2020-10-09
@update
@description 常量
*/
public interface RequestConstant {
    String TOKEN = "token";
}
